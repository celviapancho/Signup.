package com.example.userlogin

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {

    private val users = mutableMapOf<String, String>() // in-memory user storage

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {

            // ===== Custom Color Scheme =====
            val MyLightColors = lightColorScheme(
                primary = Color(0xFF6750A4),
                secondary = Color(0xFF625B71),
                background = Color(0xFFFFFFFF),
                onPrimary = Color.White,
                onSecondary = Color.White,
                surface = Color(0xFFF2F2F2),
                onSurface = Color.Black
            )

            MaterialTheme(colorScheme = MyLightColors) {
                Surface(modifier = Modifier.fillMaxSize()) {

                    var isLogin by remember { mutableStateOf(true) }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (isLogin) {
                            LoginScreen(
                                onLogin = { email, password ->
                                    val correctPassword = users[email]
                                    if (correctPassword == password) {
                                        Toast.makeText(this@MainActivity, "Login Successful", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(this@MainActivity, "Invalid credentials", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                switchToRegister = { isLogin = false }
                            )
                        } else {
                            RegisterScreen(
                                onRegister = { email, password ->
                                    if (users.containsKey(email)) {
                                        Toast.makeText(this@MainActivity, "User already exists", Toast.LENGTH_SHORT).show()
                                    } else {
                                        users[email] = password
                                        Toast.makeText(this@MainActivity, "Registration Successful", Toast.LENGTH_SHORT).show()
                                        isLogin = true
                                    }
                                },
                                switchToLogin = { isLogin = true }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LoginScreen(
    onLogin: (String, String) -> Unit,
    switchToRegister: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Text("Login", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
    Spacer(modifier = Modifier.height(16.dp))
    OutlinedTextField(
        value = email,
        onValueChange = { email = it },
        label = { Text("Email") },
        singleLine = true
    )
    Spacer(modifier = Modifier.height(8.dp))
    OutlinedTextField(
        value = password,
        onValueChange = { password = it },
        label = { Text("Password") },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation()
    )
    Spacer(modifier = Modifier.height(16.dp))
    Button(onClick = { onLogin(email, password) }) {
        Text("Login")
    }
    Spacer(modifier = Modifier.height(8.dp))
    TextButton(onClick = switchToRegister) {
        Text("Don't have an account? Register", color = MaterialTheme.colorScheme.secondary)
    }
}

@Composable
fun RegisterScreen(
    onRegister: (String, String) -> Unit,
    switchToLogin: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Text("Register", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
    Spacer(modifier = Modifier.height(16.dp))
    OutlinedTextField(
        value = email,
        onValueChange = { email = it },
        label = { Text("Email") },
        singleLine = true
    )
    Spacer(modifier = Modifier.height(8.dp))
    OutlinedTextField(
        value = password,
        onValueChange = { password = it },
        label = { Text("Password") },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation()
    )
    Spacer(modifier = Modifier.height(16.dp))
    Button(onClick = { onRegister(email, password) }) {
        Text("Register")
    }
    Spacer(modifier = Modifier.height(8.dp))
    TextButton(onClick = switchToLogin) {
        Text("Already have an account? Login", color = MaterialTheme.colorScheme.secondary)
    }
}
